/**
 * 
 */
package com.pizza.client;

/**
 * @author smitkuma
 *
 */
public class PizzaClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
